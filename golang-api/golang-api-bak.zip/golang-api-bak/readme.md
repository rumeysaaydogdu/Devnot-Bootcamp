


### Steps

1. internal/basket
    a. model.go
    b.

1. Config folder added
1. pkg folder added

```
go get github.com/labstack/echo/v4

```
