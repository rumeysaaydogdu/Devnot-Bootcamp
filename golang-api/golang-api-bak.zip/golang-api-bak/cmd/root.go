package cmd

import (
	"github.com/alperhankendi/golang-api/internal/config"
	"github.com/spf13/cobra"
)

var AppConfig config.Configuration
var rootCmd = &cobra.Command{
	Use:   "golang-api",
	Short: "A brief description of your application",
}

func Execute() {
	cobra.CheckErr(rootCmd.Execute())
}

func init() {
	cobra.OnInitialize()
}
