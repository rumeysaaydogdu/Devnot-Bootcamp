package cmd

import (
	"context"
	"fmt"
	"github.com/alperhankendi/golang-api/internal/basket"
	"github.com/alperhankendi/golang-api/internal/config"
	"github.com/alperhankendi/golang-api/pkg/echoextention"
	"github.com/alperhankendi/golang-api/pkg/graceful"
	"github.com/alperhankendi/golang-api/pkg/log"
	"github.com/alperhankendi/golang-api/pkg/mongoHelper"
	rabbit "github.com/alperhankendi/golang-api/pkg/rabbitmq"
	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"
	"time"

	"github.com/spf13/cobra"
)

var apiCmd = &cobra.Command{
	Use:   "api",
	Short: "My Resfull-API",
}

func ServerHeader(next echo.HandlerFunc) echo.HandlerFunc {
	return func(c echo.Context) error {
		c.Response().Header().Set(echo.HeaderServer, "Echo/3.0")
		return next(c)
	}
}
func init() {
	rootCmd.AddCommand(apiCmd)

	var port string
	var cfgFile string
	apiCmd.PersistentFlags().StringVarP(&port, "port", "p", "5000", "Restfull Service Port")
	apiCmd.PersistentFlags().StringVarP(&cfgFile, "config", "c", "config.dev.yaml", "config file path")
	AppConfig, err := config.GetAllValues("./config/", cfgFile)

	if err != nil {
		panic(err)
	}

	apiCmd.RunE = func(cmd *cobra.Command, args []string) error {
		var instance *echo.Echo
		instance = echo.New()
		instance.Logger = log.SetupLogger()

		//register global middleware
		instance.Use(middleware.BodyLimit("1M"))
		instance.Use(echoextention.HookGateLoggerWithConfig(echoextention.GateLoggerConfig{
			IncludeRequestBodies:  true,
			IncludeResponseBodies: true,
			Skipper:               echoextention.Myskipper,
		}))
		instance.Use(ServerHeader)

		// connect to the database
		db, err := mongoHelper.ConnectDb(AppConfig.MongoSettings)
		if err != nil {
			log.Logger.Fatalf("Database connection problem,Error:%v", err)
		}

		var rabbitClient = rabbit.NewRabbitMqClient([]string{AppConfig.RabbitMQSettings.Url}, AppConfig.RabbitMQSettings.Username, AppConfig.RabbitMQSettings.Password, "", rabbit.RetryCount(2))
		rabbitClient.AddPublisher("Basket_Direct", rabbit.Direct, basket.Basket{})
		rabbitClient.Publish(context.TODO(), "", basket.Basket{Id: "abc"})

		//bootstrapper for internal modules
		basket.RegisterHandlers(instance, basket.NewRepository(db))

		log.Logger.Info("Service is starting, will serve on ", port, " port")

		go func() {
			if err := instance.Start(fmt.Sprintf(":%s", port)); err != nil {
				log.Logger.Fatalf("shutting down the server: %v", err)
			}
		}()
		graceful.Shutdown(instance, 2*time.Second)
		return nil
	}

}
