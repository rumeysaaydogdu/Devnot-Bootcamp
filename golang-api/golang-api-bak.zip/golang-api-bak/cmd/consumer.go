package cmd

import (
	"encoding/json"
	"fmt"
	"github.com/alperhankendi/golang-api/internal/basket"
	"github.com/alperhankendi/golang-api/internal/config"
	"github.com/alperhankendi/golang-api/pkg/log"
	rabbit "github.com/alperhankendi/golang-api/pkg/rabbitmq"
	"github.com/spf13/cobra"
	"time"
)

var consumerCmd = &cobra.Command{
	Use:   "consumer",
	Short: "A brief description of your command",
}

func init() {
	rootCmd.AddCommand(consumerCmd)

	var cfgFile string
	consumerCmd.PersistentFlags().StringVarP(&cfgFile, "config", "c", "config.dev.yaml", "config file path")
	AppConfig, _ := config.GetAllValues("./config/", cfgFile)

	consumerCmd.RunE = func(cmd *cobra.Command, args []string) error {

		log.SetupLogger()
		var rabbitClient = rabbit.NewRabbitMqClient([]string{AppConfig.RabbitMQSettings.Url}, AppConfig.RabbitMQSettings.Username, AppConfig.RabbitMQSettings.Password, "", rabbit.RetryCount(2))

		onConsumed := func(message rabbit.Message) error {

			var consumeMessage basket.Basket
			var err = json.Unmarshal(message.Payload, &consumeMessage)
			if err != nil {
				return err
			}
			fmt.Println(time.Now().Format("Mon, 02 Jan 2006 15:04:05 "), " Message:", consumeMessage)
			return nil
		}
		rabbitClient.AddConsumer("basket_created").SubscriberExchange("", rabbit.Direct, "Basket_Direct").HandleConsumer(onConsumed)
		rabbitClient.RunConsumers()

		return nil
	}
}
