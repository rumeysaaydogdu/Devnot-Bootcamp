package main

import "github.com/alperhankendi/golang-api/cmd"

func main() {
	cmd.Execute()
}
